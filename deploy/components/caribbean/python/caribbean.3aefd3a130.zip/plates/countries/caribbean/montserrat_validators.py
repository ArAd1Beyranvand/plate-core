"""Port of caribbean_plate/lib/src/montserrat/src/montserrat_validators.dart."""
from __future__ import annotations

import re
from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class MontserratValidator(GatedPlateValidator):
    gate_group = "serial"
    _type = re.compile(r"^[A-Z]$")
    _serial = re.compile(r"^[0-9]{1,4}$")
    reason_type = "The type is one letter."
    reason_serial = "The number is one to four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not self._type.fullmatch(entry.group("type")):
            return PlateValidation.invalid(self.reason_type)
        if not self._serial.fullmatch(entry.group("serial")):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
