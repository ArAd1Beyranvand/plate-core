"""Port of caribbean_plate/lib/src/turks_and_caicos_islands/src/turks_and_caicos_islands_validators.dart."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


class TurksAndCaicosIslandsValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_serial = "The number is five digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not is_digits_of_length(entry.group("serial"), 5):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()


class TurksAndCaicosIslandsPrefixedValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_prefix = "The plate starts with TC."
    reason_serial = "The number is one to five digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if entry.group("prefix") != "TC":
            return PlateValidation.invalid(self.reason_prefix)
        if not re.fullmatch(r"[0-9]{1,5}", entry.group("serial")):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
