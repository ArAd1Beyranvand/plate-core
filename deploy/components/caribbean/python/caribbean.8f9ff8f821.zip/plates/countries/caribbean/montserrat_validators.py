"""Port of caribbean_plate/lib/src/montserrat/src/montserrat_validators.dart."""

from plates.core.validators.plate_validator import PlateCheck, RuledPlateValidator


class MontserratValidator(RuledPlateValidator):
    checks = (
        PlateCheck("type", r"[A-Z]", "The type is one letter."),
        PlateCheck("serial", r"[0-9]{1,4}", "The number is one to four digits."),
    )
