"""Port of federated_states_of_micronesia_plate/lib/src/federated_states_of_micronesia_validators.dart."""
from __future__ import annotations

import re
from dataclasses import dataclass

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


@dataclass(frozen=True)
class FederatedStatesOfMicronesiaValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_serial = "The serial is four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        serial = entry.group("serial")
        if not is_digits_of_length(serial, 4):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
