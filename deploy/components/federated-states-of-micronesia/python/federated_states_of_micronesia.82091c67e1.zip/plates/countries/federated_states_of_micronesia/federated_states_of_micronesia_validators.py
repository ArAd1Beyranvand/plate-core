"""Port of federated_states_of_micronesia_plate/lib/src/federated_states_of_micronesia_validators.dart."""

from plates.core.validators.plate_validator import PlateCheck, RuledPlateValidator


class FederatedStatesOfMicronesiaValidator(RuledPlateValidator):
    checks = (
        PlateCheck("serial", r"[0-9]{4}", "The serial is four digits."),
    )
