"""Port of seychelles_plate/lib/src/seychelles_validators.dart."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class SeychellesValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_letter = "The series is one letter."
    reason_serial = "The number is one to five digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch(r"[A-Z]", entry.group("letter")):
            return PlateValidation.invalid(self.reason_letter)
        if not re.fullmatch(r"[0-9]{1,5}", entry.group("serial")):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
