"""Port of rwanda_plate/lib/src/rwanda_validators.dart."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class RwandaValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_register = "The register is three letters starting with R."
    reason_serial = "The number is three digits and a letter."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch(r"R[A-Z]{2}", entry.group("register")):
            return PlateValidation.invalid(self.reason_register)
        if not re.fullmatch(r"[0-9]{3}[A-Z]", entry.group("serial")):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
