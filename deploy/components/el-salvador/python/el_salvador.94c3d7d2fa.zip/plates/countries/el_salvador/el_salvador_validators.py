"""Port of el_salvador_plate/lib/src/el_salvador_validators.dart."""
from __future__ import annotations

import re
from dataclasses import dataclass

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


@dataclass(frozen=True)
class ElSalvadorValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_letter = "The class is one letter."
    reason_serial = "The number is four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch(r"[A-Z]", entry.group("letter")):
            return PlateValidation.invalid(self.reason_letter)
        if not is_digits_of_length(entry.group("serial"), 4):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()


@dataclass(frozen=True)
class ElSalvadorMotorcycleValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_letter = "The class is one letter."
    reason_series = "The series is one digit."
    reason_serial = "The number is three digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch(r"[A-Z]", entry.group("letter")):
            return PlateValidation.invalid(self.reason_letter)
        if not is_digits_of_length(entry.group("series"), 1):
            return PlateValidation.invalid(self.reason_series)
        if not is_digits_of_length(entry.group("serial"), 3):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
