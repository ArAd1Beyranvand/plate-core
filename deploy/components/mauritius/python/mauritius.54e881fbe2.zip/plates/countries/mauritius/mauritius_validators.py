"""Port of mauritius_plate/lib/src/mauritius_validators.dart."""

from plates.core.validators.plate_validator import PlateCheck, RuledPlateValidator


class MauritiusValidator(RuledPlateValidator):
    checks = (
        PlateCheck("letters", r"[A-Z]{2}", "The prefix is two letters."),
        PlateCheck("serial", r"[0-9]{4}", "The number is four digits."),
    )
