"""Port of burundi_plate/lib/src/burundi_validators.dart."""
from __future__ import annotations

import re
from dataclasses import dataclass

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


@dataclass(frozen=True)
class BurundiValidator(GatedPlateValidator):
    gate_group = "number"
    _letter = re.compile(r"^[A-Z]$")

    def judge(self, entry: PlateEntry) -> PlateValidation:
        prefix = entry.group("prefix")
        number = entry.group("number")
        suffix = entry.group("suffix")
        if not self._letter.fullmatch(prefix):
            return PlateValidation.invalid("The prefix is 1 letter.")
        if not is_digits_of_length(number, 4):
            return PlateValidation.invalid("The number is 4 digits.")
        if not self._letter.fullmatch(suffix):
            return PlateValidation.invalid("The suffix is 1 letter.")
        return PlateValidation.valid()
