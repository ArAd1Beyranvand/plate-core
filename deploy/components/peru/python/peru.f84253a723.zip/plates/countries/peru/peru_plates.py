"""Port of peru_plate/lib/src/peru_plates.dart. Hand-ported; codegen never overwrites this file."""
from __future__ import annotations


class PeruPlates:
    @staticmethod
    def _sticker_text(group):
        register, serial = group("register"), group("serial")
        return f"{register}-{serial}" if register or serial else None
