"""Port of uganda_plate/lib/src/uganda_validators.dart. Hand-ported; codegen never overwrites this file."""
from __future__ import annotations

import re
from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class UgandaValidator(GatedPlateValidator):
    gate_group = "number"
    _series = re.compile(r"^[A-Z]{2}$")
    _number = re.compile(r"^[0-9]{4,5}$")
    reason_series = "The series is two letters."
    reason_number = "The number is four or five digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not self._series.fullmatch(entry.group("series")):
            return PlateValidation.invalid(self.reason_series)
        if not self._number.fullmatch(entry.group("number")):
            return PlateValidation.invalid(self.reason_number)
        return PlateValidation.valid()
