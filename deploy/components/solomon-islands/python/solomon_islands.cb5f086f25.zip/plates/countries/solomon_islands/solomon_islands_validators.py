"""Port of solomon_islands_plate/lib/src/solomon_islands_validators.dart."""

from plates.core.validators.plate_validator import PlateCheck, RuledPlateValidator


class SolomonIslandsValidator(RuledPlateValidator):
    checks = (
        PlateCheck("series", r"[A-Z]{2}", "The series is two letters."),
        PlateCheck("serial", r"[0-9]{4}", "The serial is four digits."),
    )
