"""Port of solomon_islands_plate/lib/src/solomon_islands_validators.dart."""
from __future__ import annotations

import re
from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


class SolomonIslandsValidator(GatedPlateValidator):
    gate_group = "serial"
    _series = re.compile(r"^[A-Z]{2}$")
    reason_series = "The series is two letters."
    reason_serial = "The serial is four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not self._series.fullmatch(entry.group("series")):
            return PlateValidation.invalid(self.reason_series)
        if not is_digits_of_length(entry.group("serial"), 4):
            return PlateValidation.invalid(self.reason_serial)
        return PlateValidation.valid()
