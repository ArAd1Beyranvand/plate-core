"""Port of guatemala_plate/lib/src/guatemala_validators.dart."""
from __future__ import annotations

import re
from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class GuatemalaValidator(GatedPlateValidator):
    gate_group = "letters"

    reason_class = "The class is one letter, such as P or C."
    reason_digits = "The number is three digits."
    reason_letters = "The serial ends in three letters."

    _class = re.compile(r"^[A-Z]$")
    _digits = re.compile(r"^[0-9]{3}$")
    _letters = re.compile(r"^[A-Z]{3}$")

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not self._class.fullmatch(entry.group("class")):
            return PlateValidation.invalid(self.reason_class)
        if not self._digits.fullmatch(entry.group("digits")):
            return PlateValidation.invalid(self.reason_digits)
        if not self._letters.fullmatch(entry.group("letters")):
            return PlateValidation.invalid(self.reason_letters)
        return PlateValidation.valid()
