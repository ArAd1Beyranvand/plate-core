"""Port of zambia_plate/lib/src/zambia_validators.dart."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class ZambiaValidator(GatedPlateValidator):
    gate_group = "serial"
    reason_prefix = "The prefix is three letters."
    reason_serial = "The number is four digits."
    reason_suffix = "The suffix is one letter."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch(r"[A-Z]{3}", entry.group("prefix")):
            return PlateValidation.invalid(self.reason_prefix)
        if not re.fullmatch(r"[0-9]{4}", entry.group("serial")):
            return PlateValidation.invalid(self.reason_serial)
        if not re.fullmatch(r"[A-Z]", entry.group("suffix")):
            return PlateValidation.invalid(self.reason_suffix)
        return PlateValidation.valid()
