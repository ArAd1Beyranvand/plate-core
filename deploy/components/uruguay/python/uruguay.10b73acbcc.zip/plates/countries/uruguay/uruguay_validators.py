"""Port of uruguay_plate/lib/src/uruguay_validators.dart. Hand-ported; codegen never overwrites this file."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class UruguayValidator(GatedPlateValidator):
    gate_group = 'number'

    reason_letters = "A serial is three letters, the first a department code (A to S)."
    reason_number = "The number is one to four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if re.fullmatch(r"[A-S][A-Z]{2}", entry.group("first")) is None:
            return PlateValidation.invalid(self.reason_letters)
        if re.fullmatch(r"[0-9]{1,4}", entry.group("number")) is None:
            return PlateValidation.invalid(self.reason_number)
        return PlateValidation.valid()
