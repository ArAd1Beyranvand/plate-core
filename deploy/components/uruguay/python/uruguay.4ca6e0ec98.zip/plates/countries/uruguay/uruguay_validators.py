"""Port of uruguay_plate/lib/src/uruguay_validators.dart. Hand-ported; codegen never overwrites this file."""

from plates.core.validators.plate_validator import PlateCheck, RuledPlateValidator


class UruguayValidator(RuledPlateValidator):
    checks = (
        PlateCheck("first", r"[A-S][A-Z]{2}", "A serial is three letters, the first a department code (A to S)."),
        PlateCheck("number", r"[0-9]{1,4}", "The number is one to four digits."),
    )
