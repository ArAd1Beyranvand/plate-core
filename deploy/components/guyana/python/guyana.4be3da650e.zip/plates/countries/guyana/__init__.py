"""guyana: `data` holds the generated specs, the other modules the hand-ported units."""
