"""Port of guyana_plate/lib/src/french_guiana/src/french_guiana_validators.dart."""
from __future__ import annotations

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class FrenchGuianaValidator(GatedPlateValidator):
    gate_group = "number"
    reason_field = "A field has the wrong length or characters."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        spec = entry.spec
        for i in range(len(spec.slots)):
            slot = spec.slots[i]
            v = entry.group(spec.text_groups[i].key)
            if not slot.accepts(v) or len(v) < slot.min_length or len(v) > slot.length:
                return PlateValidation.invalid(self.reason_field)
        return PlateValidation.valid()
