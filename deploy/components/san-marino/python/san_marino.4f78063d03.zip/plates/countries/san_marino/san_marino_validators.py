"""Port of san_marino_plate/lib/src/san_marino_validators.dart."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class SanMarinoValidator(GatedPlateValidator):
    gate_group = "number"
    reason_prefix = "The prefix is one to seven letters."
    reason_number = "The number is one to four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if re.fullmatch(r"[A-Z]{1,7}", entry.group("prefix")) is None:
            return PlateValidation.invalid(self.reason_prefix)
        if re.fullmatch(r"[0-9]{1,4}", entry.group("number")) is None:
            return PlateValidation.invalid(self.reason_number)
        return PlateValidation.valid()
