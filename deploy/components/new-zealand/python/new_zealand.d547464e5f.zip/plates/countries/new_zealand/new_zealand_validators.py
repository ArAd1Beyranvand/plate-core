"""Port of new_zealand_plate/lib/src/new_zealand_validators.dart. Hand-ported; codegen never overwrites this file."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length

class NewZealandValidator(GatedPlateValidator):
    gate_group = "serial"
    REASON_LETTERS = "The letters are three capitals."
    REASON_SERIAL = "The number is three digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch("[A-Z]{3}", entry.group("letters")):
            return PlateValidation.invalid(self.REASON_LETTERS)
        if not is_digits_of_length(entry.group("serial"), 3):
            return PlateValidation.invalid(self.REASON_SERIAL)
        return PlateValidation.valid()


class NewZealandLegacyValidator(GatedPlateValidator):
    gate_group = "serial"
    REASON_LETTERS = "The letters are two capitals."
    REASON_SERIAL = "The number is four digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not re.fullmatch("[A-Z]{2}", entry.group("letters")):
            return PlateValidation.invalid(self.REASON_LETTERS)
        if not is_digits_of_length(entry.group("serial"), 4):
            return PlateValidation.invalid(self.REASON_SERIAL)
        return PlateValidation.valid()


class NewZealandPersonalisedValidator(GatedPlateValidator):
    gate_group = "serial"
    REASON_RUN = "A personalised plate is one to six letters or digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if re.fullmatch("[A-Z0-9]{1,6}", entry.group("serial")):
            return PlateValidation.valid()
        return PlateValidation.invalid(self.REASON_RUN)
