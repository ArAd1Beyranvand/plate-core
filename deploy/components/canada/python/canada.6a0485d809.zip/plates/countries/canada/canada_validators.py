"""Port of canada_plate/lib/src/canada_validators.dart."""
from __future__ import annotations

import re
from dataclasses import dataclass

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


@dataclass(frozen=True)
class CanadaFederalValidator(GatedPlateValidator):
    gate_group = "number"
    reason_number = "A federal plate has five digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not is_digits_of_length(entry.group("number"), 5):
            return PlateValidation.invalid(self.reason_number)
        return PlateValidation.valid()


@dataclass(frozen=True)
class CanadaPermitValidator(GatedPlateValidator):
    gate_group = "letter"
    reason_letter = "A permit starts with one letter."
    reason_unused = "I, O, Q and U are not used in serials."
    reason_number = "A permit has six digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        letter = entry.group("letter")
        if len(letter) != 1:
            return PlateValidation.invalid(self.reason_letter)
        if letter in "IOQU":
            return PlateValidation.invalid(self.reason_unused)
        if not is_digits_of_length(entry.group("number"), 6):
            return PlateValidation.invalid(self.reason_number)
        return PlateValidation.valid()
