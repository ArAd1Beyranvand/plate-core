"""Port of paraguay_plate/lib/src/paraguay_validators.dart. Hand-ported; codegen never overwrites this file."""
from __future__ import annotations

import re

from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation


class ParaguayValidator(GatedPlateValidator):
    gate_group = 'number'

    reason_letters = "The series is four letters."
    reason_number = "The number is three digits."

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if re.fullmatch(r"[A-Z]{4}", entry.group("letters")) is None:
            return PlateValidation.invalid(self.reason_letters)
        if re.fullmatch(r"[0-9]{3}", entry.group("number")) is None:
            return PlateValidation.invalid(self.reason_number)
        return PlateValidation.valid()
