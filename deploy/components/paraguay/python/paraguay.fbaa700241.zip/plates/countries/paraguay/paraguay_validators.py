"""Port of paraguay_plate/lib/src/paraguay_validators.dart. Hand-ported; codegen never overwrites this file."""

from plates.core.validators.plate_validator import PlateCheck, RuledPlateValidator


class ParaguayValidator(RuledPlateValidator):
    checks = (
        PlateCheck("letters", r"[A-Z]{4}", "The series is four letters."),
        PlateCheck("number", r"[0-9]{3}", "The number is three digits."),
    )
