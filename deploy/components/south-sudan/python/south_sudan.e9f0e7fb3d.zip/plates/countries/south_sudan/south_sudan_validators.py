"""Port of south_sudan_plate/lib/src/south_sudan_validators.dart."""
from __future__ import annotations

import re
from plates.core.validators.plate_validator import GatedPlateValidator, PlateEntry, PlateValidation, is_digits_of_length


class SouthSudanValidator(GatedPlateValidator):
    gate_group = "letters"
    reason_serial = "The number is three digits."
    reason_letters = "The register is one or two letters."
    _letters = re.compile(r"^[A-Z]{1,2}$")

    def judge(self, entry: PlateEntry) -> PlateValidation:
        if not is_digits_of_length(entry.group("serial"), 3):
            return PlateValidation.invalid(self.reason_serial)
        if not self._letters.fullmatch(entry.group("letters")):
            return PlateValidation.invalid(self.reason_letters)
        return PlateValidation.valid()
